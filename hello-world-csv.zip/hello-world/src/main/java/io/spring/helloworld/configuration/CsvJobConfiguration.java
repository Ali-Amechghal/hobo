package io.spring.helloworld.configuration;

import io.spring.helloworld.configuration.domain.Article;
import io.spring.helloworld.configuration.dto.ArticleDto;
import io.spring.helloworld.configuration.mapper.CsvFileLineMapper;
import io.spring.helloworld.configuration.processor.CsvDataLineProcessor;
import io.spring.helloworld.configuration.reader.CsvFileReader;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;


@Configuration
public class CsvJobConfiguration extends BatchJobConfiguration {

    @Bean
    public Job csvArticleJob(ItemReader<ArticleDto> csvItemReader, @Qualifier("csvDatabaseWriter") ItemWriter<Article> itemWriter) {
        return jobBuilderFactory.get("CsvJob")
                .incrementer(new RunIdIncrementer())
               // .listener(jobExecutionListenerSupport())
                .start(csvFileReadStep(csvItemReader, itemWriter))
                .build();
    }
    @Bean
    public Step csvFileReadStep(ItemReader<ArticleDto> csvItemReader, @Qualifier("csvDatabaseWriter") ItemWriter<Article> itemWriter) {
        return stepBuilderFactory.get("CsvFileReader")
                .<ArticleDto, Article>chunk(2)
                .reader(csvItemReader)
                .processor(csvFileProcessor())
                .writer(itemWriter)
               // .taskExecutor(threadPoolTaskExecutor())
                .throttleLimit(5)
                .build();
    }

    @Bean
    ItemProcessor<ArticleDto, Article> csvFileProcessor() {
        return new CsvDataLineProcessor();
    }

    @Bean
    public ItemReader<ArticleDto> csvItemReader(@Value("${input}") Resource resource){

        CsvFileReader<ArticleDto> csvFileReader = new CsvFileReader<>();
        csvFileReader.setResource(resource.exists() ? resource : new ClassPathResource(resource.getFilename()));
        csvFileReader.setLineMapper(csvLineMapper());
        csvFileReader.setEncoding("UTF-8");
        return csvFileReader;
    }

    @Bean
    public LineMapper<ArticleDto> csvLineMapper() {
        CsvFileLineMapper<ArticleDto> csvLineMapper = new CsvFileLineMapper<>();
        csvLineMapper.setLineTokenizer(new DelimitedLineTokenizer());
        csvLineMapper.setFieldSetMapper(csvFieldSetMapper());
        return csvLineMapper;

    }

    @Bean
    public FieldSetMapper<ArticleDto> csvFieldSetMapper() {
        return new CsvFieldMapper();
    }


}
