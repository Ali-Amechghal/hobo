package io.spring.helloworld.configuration;

import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FlowConfiguration {
    @Autowired
    private StepBuilderFactory stepBuilderFactory;


    @Bean
    public Step firstFlowStep() {
        return  stepBuilderFactory.get("flowstep1")
                .tasklet(((stepContribution, chunkContext) ->{
                    System.out.println("first flow step1 : "+chunkContext.getStepContext().getJobName()+" : "+Thread.currentThread());
                    return RepeatStatus.FINISHED;
                })).build();
    }

    @Bean
    public Step secondFlowStep() {
        return  stepBuilderFactory.get("secondstep1")
                .tasklet(((stepContribution, chunkContext) ->{
                    System.out.println("first flow step2");
                    return RepeatStatus.FINISHED;
                })).build();
    }

    @Bean
    public Step splitFlowSTep() {
        return  stepBuilderFactory.get("Splited flow sep")
                .tasklet(((stepContribution, chunkContext) ->{
                    System.out.println("Splited flow sep : "+chunkContext.getStepContext().getJobName()+" : "+Thread.currentThread());
                    return RepeatStatus.FINISHED;
                })).build();
    }

    @Bean
    public Flow flow(){
        FlowBuilder<Flow> fb =  new FlowBuilder<>("mailflow");
        fb.start(firstFlowStep())
                .next(secondFlowStep())
                .end();

        return fb.build();
    }
    @Bean
    public Flow flowSplit(){
        FlowBuilder<Flow> fb =  new FlowBuilder<>("flowsplit");
        fb.start(splitFlowSTep())
                .end();

        return fb.build();
    }

}
