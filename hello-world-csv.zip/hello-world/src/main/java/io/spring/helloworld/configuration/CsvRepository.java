package io.spring.helloworld.configuration;

import io.spring.helloworld.configuration.domain.Article;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvRepository extends JpaRepository<Article, Long> {
}
