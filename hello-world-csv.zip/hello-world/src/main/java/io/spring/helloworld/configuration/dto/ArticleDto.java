package io.spring.helloworld.configuration.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

public class ArticleDto implements Serializable {
//id;created_at;created_by;title;description;price
    private int id;
    private Date createdAt;
    private String createdBy;
    private String title;
    private String description;
    private double price;

    public ArticleDto() {
    }

    public ArticleDto(int id, Date createdAt, String createdBy, String title, String description, double price) {
        this.id = id;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.title = title;
        this.description = description;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ArticleDto{" +
                "id=" + id +
                ", createdAt=" + createdAt +
                ", createdBy='" + createdBy + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                '}';
    }
}
