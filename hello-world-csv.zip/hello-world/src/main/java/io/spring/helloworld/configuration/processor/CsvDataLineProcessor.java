package io.spring.helloworld.configuration.processor;

import io.spring.helloworld.configuration.domain.Article;
import io.spring.helloworld.configuration.dto.ArticleDto;
import org.springframework.batch.item.ItemProcessor;

public class CsvDataLineProcessor implements ItemProcessor<ArticleDto, Article> {


    @Override
    public Article process(ArticleDto articleDto) {
        Article ar =  new Article(articleDto.getId(), articleDto.getCreatedAt(), articleDto.getCreatedBy(), articleDto.getTitle(),
                articleDto.getDescription(),articleDto.getPrice());

        return ar;

    }
}