package io.spring.helloworld.configuration.writer;

import io.spring.helloworld.configuration.CsvRepository;
import io.spring.helloworld.configuration.domain.Article;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class DatabaseWriter {

    @Bean(name = "csvDatabaseWriter")
    RepositoryItemWriter<Article> dfeRepositoryItemWriter(CsvRepository csvRepository) {
        RepositoryItemWriter<Article> repositoryItemWriter = new RepositoryItemWriter<>();
        repositoryItemWriter.setRepository(csvRepository);
        repositoryItemWriter.setMethodName("save");
        return repositoryItemWriter;
    }


}
