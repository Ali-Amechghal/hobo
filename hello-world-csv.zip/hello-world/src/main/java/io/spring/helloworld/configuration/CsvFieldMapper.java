package io.spring.helloworld.configuration;

import io.spring.helloworld.configuration.dto.ArticleDto;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class CsvFieldMapper implements FieldSetMapper<ArticleDto> {
    @Override
    public ArticleDto mapFieldSet(FieldSet fieldSet) throws BindException {
        return  new ArticleDto(fieldSet.readInt(0),
                fieldSet.readDate(1),
                fieldSet.readString(2),
                fieldSet.readString(3),
                fieldSet.readString(4),
                fieldSet.readDouble(5)
                );
    }
}
